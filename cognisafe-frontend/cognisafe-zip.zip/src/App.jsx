import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Auth      from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import Session   from "./pages/Session";
import Brain     from "./pages/Brain";
import ARReport  from "./pages/ARReport";

const App = () => (
  <BrowserRouter>
    <Routes>
      <Route path="/"          element={<Navigate to="/auth" replace />} />
      <Route path="/auth"      element={<Auth />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/session"   element={<Session />} />
      <Route path="/brain"     element={<Brain />} />
      <Route path="/ar-report" element={<ARReport />} />
    </Routes>
  </BrowserRouter>
);

export default App;