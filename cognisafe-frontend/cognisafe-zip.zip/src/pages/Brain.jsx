import { useState } from "react";
import Navbar from "../components/common/Navbar";
import "../styles/brain.css";
import "../styles/global.css";

const REGIONS = [
  { name: "Prefrontal cortex", score: 88, color: "#9B87F5" },
  { name: "Temporal lobe",     score: 72, color: "#F9C8D8" },
  { name: "Parietal lobe",     score: 91, color: "#A8D8B8" },
  { name: "Broca's area",      score: 79, color: "#F5D898" },
  { name: "Wernicke's area",   score: 85, color: "#C4B0F8" },
  { name: "Cerebellum",        score: 94, color: "#A8D8B8" },
];

const MONTHS = ["Sep","Oct","Nov","Dec","Jan","Now"];

const Brain = () => {
  const [hovered, setHovered] = useState(null);
  const [month, setMonth] = useState(5);

  return (
    <div className="brain-root page-enter">
      <Navbar />
      <div className="brain-body">

        <div className="brain-header">
          <div className="brain-header-sub">Neural heatmap · real-time</div>
          <div className="brain-header-title">Your <em>brain health</em> visualised</div>
        </div>

        <div className="brain-stats-row">
          <div className="bstat">
            <div className="bstat-label">Overall score</div>
            <div className="bstat-val">84</div>
            <div className="bstat-sub">out of 100 · 78th percentile</div>
            <div className="bstat-pill great">Above average</div>
          </div>
          <div className="bstat">
            <div className="bstat-label">Weakest region</div>
            <div className="bstat-val" style={{ fontSize: 22, color: "#F9A8B8", marginTop: 8 }}>Temporal lobe</div>
            <div className="bstat-sub">Score 72 · needs monitoring</div>
            <div className="bstat-pill warn">Watch closely</div>
          </div>
          <div className="bstat">
            <div className="bstat-label">Strongest region</div>
            <div className="bstat-val" style={{ fontSize: 22, color: "#A8D8B8", marginTop: 8 }}>Cerebellum</div>
            <div className="bstat-sub">Score 94 · excellent</div>
            <div className="bstat-pill good">Excellent</div>
          </div>
        </div>

        <div className="brain-grid">
          <div className="b-card">
            <div className="b-card-title">Neural heatmap</div>
            <div className="b-card-sub">
              {hovered ? `${hovered.name}: ${hovered.score}/100` : "Hover a region to inspect"}
            </div>
            <div className="brain-svg-wrap">
              <svg width="220" height="180" viewBox="0 0 220 180">
                <ellipse cx="110" cy="90" rx="80" ry="62" fill="#F5F0FF" stroke="#DDD5F5" strokeWidth="1.5"/>
                {[
                  { cx:78,  cy:62,  rx:32, ry:22, region: REGIONS[0] },
                  { cx:142, cy:62,  rx:32, ry:22, region: REGIONS[1] },
                  { cx:110, cy:100, rx:30, ry:20, region: REGIONS[2] },
                  { cx:72,  cy:112, rx:22, ry:15, region: REGIONS[3] },
                  { cx:148, cy:112, rx:22, ry:15, region: REGIONS[4] },
                  { cx:110, cy:130, rx:20, ry:14, region: REGIONS[5] },
                ].map(({ cx, cy, rx, ry, region }) => (
                  <ellipse key={region.name} cx={cx} cy={cy} rx={rx} ry={ry}
                    fill={region.color + "88"} stroke={region.color} strokeWidth="1"
                    className="breg" style={{ cursor: "pointer" }}
                    onMouseEnter={() => setHovered(region)}
                    onMouseLeave={() => setHovered(null)}
                  />
                ))}
                {hovered && (
                  <g>
                    <rect x="55" y="8" width="110" height="24" rx="6" fill="#2D2545"/>
                    <text x="110" y="24" textAnchor="middle" fontSize="11" fill="#E0D8F8" fontFamily="Inter,sans-serif">
                      {hovered.name}: {hovered.score}/100
                    </text>
                  </g>
                )}
              </svg>
            </div>
            <div className="region-list">
              {REGIONS.map(r => (
                <div className="region-row" key={r.name}>
                  <div className="region-dot" style={{ background: r.color }} />
                  <span className="region-name">{r.name}</span>
                  <div className="region-bar-track">
                    <div className="region-bar-fill" style={{ width: `${r.score}%`, background: r.color }} />
                  </div>
                  <span className="region-score" style={{ color: r.color }}>{r.score}</span>
                </div>
              ))}
            </div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div className="time-slider-card">
              <div className="ts-header">
                <span className="ts-title">6-month trajectory</span>
                <span className="ts-delta">▲ +6 pts overall</span>
              </div>
              <div className="ts-track">
                <div className="ts-line" />
                {MONTHS.map((m, i) => (
                  <div key={m}
                    className={`ts-dot ${i === month ? "now" : ""}`}
                    style={{ left: `${(i / (MONTHS.length - 1)) * 100}%` }}
                    onClick={() => setMonth(i)}
                    title={m}
                  />
                ))}
              </div>
              <div className="ts-labels">{MONTHS.map(m => <span key={m}>{m}</span>)}</div>
              <input type="range" className="ts-input" min={0} max={5} value={month}
                onChange={e => setMonth(Number(e.target.value))} />
              <div style={{ marginTop: 10, fontSize: 12, color: "#9080B8" }}>
                Viewing: <b style={{ color: "#6B52D6" }}>{MONTHS[month]}</b> — Overall score: <b style={{ color: "#6B52D6" }}>{74 + month * 2}</b>/100
              </div>
            </div>

            <div className="b-card">
              <div className="b-card-title">Region insights</div>
              <div className="b-card-sub">Tap any region on the brain map</div>
              {hovered ? (
                <div>
                  <div style={{ fontSize: 22, fontWeight: 600, color: hovered.color, marginBottom: 6, fontFamily: "'Playfair Display', serif" }}>
                    {hovered.name}
                  </div>
                  <div style={{ fontSize: 13, color: "#9080B8", lineHeight: 1.7 }}>
                    Score: <b style={{ color: "#2D2545" }}>{hovered.score}/100</b><br />
                    Status: <b style={{ color: hovered.score > 80 ? "#2A9060" : "#A07010" }}>
                      {hovered.score > 85 ? "Excellent" : hovered.score > 75 ? "Good" : "Watch closely"}
                    </b>
                  </div>
                </div>
              ) : (
                <div style={{ fontSize: 13, color: "#C8B8E8", fontStyle: "italic" }}>
                  No region selected — hover the brain map
                </div>
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default Brain;