import Navbar from "../components/common/Navbar";
import "../styles/arreport.css";
import "../styles/global.css";

const METRICS = [
  { name: "Semantic coherence", val: "0.81", trend: "▲ +2.1%", dir: "up"  },
  { name: "Cognitive age",      val: "52",   trend: "▲ Stable", dir: "up"  },
  { name: "Risk tier",          val: "Green",trend: "▲ Good",   dir: "up"  },
  { name: "Sessions this week", val: "5/7",  trend: "— On track",dir: "flat"},
  { name: "Streak",             val: "12d",  trend: "▲ Growing", dir: "up" },
  { name: "Lexical diversity",  val: "0.74", trend: "▼ Watch",  dir: "down"},
];

const ARReport = () => (
  <div className="ar-root page-enter">
    <Navbar />
    <div className="ar-body">

      <div className="ar-header">
        <div className="ar-header-sub">Weekly report · 17–20 March 2026</div>
        <div className="ar-header-title">Your <em>cognitive report</em> — ready to share</div>
      </div>

      <div className="ar-card">
        <div className="ar-accent" />
        <div className="ar-card-title">Weekly metrics summary</div>
        <div className="ar-card-sub">Powered by 14 voice biomarkers</div>
        <div className="ar-metrics">
          {METRICS.map(m => (
            <div className="arm-row" key={m.name}>
              <span className="arm-name">{m.name}</span>
              <span className="arm-val">{m.val}</span>
              <span className={`arm-trend ${m.dir}`}>{m.trend}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        <div className="ar-card">
          <div className="ar-card-title">AR overlay</div>
          <div className="ar-card-sub">Scan to launch live 3D data above this report</div>
          <div className="qr-section">
            <div className="qr-box">
              <svg width="70" height="70" viewBox="0 0 60 60" fill="none">
                <rect x="4"  y="4"  width="22" height="22" rx="2" stroke="#9B87F5" strokeWidth="2" fill="none"/>
                <rect x="9"  y="9"  width="12" height="12" rx="1" fill="#9B87F5"/>
                <rect x="34" y="4"  width="22" height="22" rx="2" stroke="#9B87F5" strokeWidth="2" fill="none"/>
                <rect x="39" y="9"  width="12" height="12" rx="1" fill="#9B87F5"/>
                <rect x="4"  y="34" width="22" height="22" rx="2" stroke="#9B87F5" strokeWidth="2" fill="none"/>
                <rect x="9"  y="39" width="12" height="12" rx="1" fill="#9B87F5"/>
                <rect x="34" y="34" width="6" height="6" fill="#F9C8D8"/>
                <rect x="42" y="34" width="6" height="6" fill="#C4B0F8"/>
                <rect x="50" y="34" width="6" height="6" fill="#F9C8D8"/>
                <rect x="34" y="42" width="6" height="6" fill="#C4B0F8"/>
                <rect x="42" y="42" width="6" height="6" fill="#9B87F5"/>
                <rect x="50" y="50" width="6" height="6" fill="#9B87F5"/>
              </svg>
            </div>
            <div className="qr-hint">Point your phone camera at this code to launch AR report overlay</div>
            <button className="qr-btn">Download PDF report</button>
          </div>
        </div>

        <div className="ar-card">
          <div className="fhir-badge">✓ FHIR R4 Ready</div>
          <div className="ar-card-title">EHR export</div>
          <div className="ar-card-sub">Push directly to your doctor's system</div>
          <div className="fhir-code">
            {"{\n  \"resourceType\": \"Observation\",\n  \"status\": \"final\",\n  \"code\": \"cognitive-biomarker\",\n  \"subject\": \"Patient/arjun-sharma\",\n  \"valueQuantity\": 0.81\n}"}
          </div>
          <button className="fhir-btn">Push to EHR system</button>
        </div>
      </div>

    </div>
  </div>
);

export default ARReport;