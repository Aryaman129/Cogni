import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/common/Navbar";
import "../styles/session.css";
import "../styles/global.css";

const PROMPTS = [
  "Describe what you see in this image in as much detail as you can.",
  "Tell me about your most memorable childhood experience.",
  "Explain how you would describe your home to a stranger.",
  "Describe what you did yesterday from morning to evening.",
];

const Session = () => {
  const navigate = useNavigate();
  const [state, setState] = useState("idle"); // idle | recording | done
  const [progress, setProgress] = useState(33);
  const [prompt] = useState(PROMPTS[Math.floor(Math.random() * PROMPTS.length)]);
  const timerRef = useRef(null);

  const toggleRecording = () => {
    if (state === "done") return;
    if (state === "idle") {
      setState("recording");
      timerRef.current = setInterval(() => {
        setProgress(p => {
          if (p >= 99) { clearInterval(timerRef.current); setState("done"); return 100; }
          return p + 1.2;
        });
      }, 120);
    } else {
      clearInterval(timerRef.current);
      setState("done");
      setProgress(100);
    }
  };

  useEffect(() => () => clearInterval(timerRef.current), []);

  const statusText = state === "idle" ? "Ready to record"
    : state === "recording" ? "Recording…"
    : "Analysis complete ✓";
  const statusClass = state === "recording" ? "rec" : state === "done" ? "done" : "";
  const btnText = state === "idle" ? "Start Recording"
    : state === "recording" ? "Stop Recording"
    : "Recording Done ✓";

  return (
    <div className="session-root page-enter">
      <Navbar />
      <div className="session-body">

        <div className="prompt-card">
          <div className="prompt-label">Today's prompt — Session 25</div>
          <div className="prompt-text">"{prompt}"</div>
        </div>

        <div className="orb-container">
          <div className="orb-ring" />
          <div className="orb-ring" />
          <div className="orb-ring" />
          <div className={`orb ${state}`} onClick={toggleRecording} />
        </div>

        <div className={`orb-status ${statusClass}`}>
          Status: <b>{statusText}</b>
        </div>

        <div className="sess-controls">
          <button
            className={`btn-record ${state === "recording" ? "recording" : ""}`}
            onClick={toggleRecording}
            disabled={state === "done"}
          >
            {btnText}
          </button>
          <button className="btn-skip" onClick={() => navigate("/dashboard")}>
            Skip prompt
          </button>
        </div>

        <div className="sess-progress">
          <div className="prog-bar-track">
            <div className="prog-bar-fill" style={{ width: `${progress}%` }} />
          </div>
          <div className="prog-steps">
            <span>Baseline</span>
            <span>Session 25</span>
            <span>Analysis</span>
          </div>
        </div>

        {state === "done" && (
          <div className="result-card">
            <div className="result-title">
              Session results
              <span className="result-pill">✓ Processed</span>
            </div>
            <div className="result-grid">
              <div className="result-metric">
                <div className="rm-label">Semantic coherence</div>
                <div className="rm-val">0.83</div>
                <div className="rm-trend">▲ +2.4% today</div>
              </div>
              <div className="result-metric">
                <div className="rm-label">Speech rate</div>
                <div className="rm-val">121</div>
                <div className="rm-trend">▲ Stable</div>
              </div>
              <div className="result-metric">
                <div className="rm-label">Pause frequency</div>
                <div className="rm-val">2.8</div>
                <div className="rm-trend">▲ Improved</div>
              </div>
              <div className="result-metric">
                <div className="rm-label">Risk tier</div>
                <div className="rm-val" style={{ color: "#2A9060" }}>Green</div>
                <div className="rm-trend">▲ No change</div>
              </div>
            </div>
            <button className="result-btn" onClick={() => navigate("/dashboard")}>
              Back to dashboard
            </button>
          </div>
        )}

      </div>
    </div>
  );
};

export default Session;