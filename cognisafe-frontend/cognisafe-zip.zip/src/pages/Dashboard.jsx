import { useRef, useEffect, useState } from "react";
import "../styles/dashboard.css";

const BIOMARKERS = [
  { name: "Semantic\ncoherence",   val: "0.81", tr: "+2.1%", dir: "up",   st: "good" },
  { name: "Lexical\ndiversity",    val: "0.74", tr: "-0.8%", dir: "down", st: "warn" },
  { name: "Idea\ndensity",         val: "0.61", tr: "+1.4%", dir: "up",   st: "good" },
  { name: "Speech\nrate",          val: "118",  tr: "0.0%",  dir: "flat", st: "good" },
  { name: "Pause\nfrequency",      val: "3.2",  tr: "+5.2%", dir: "down", st: "warn" },
  { name: "Pause\nduration",       val: "0.42", tr: "-1.1%", dir: "up",   st: "good" },
  { name: "Pitch\nmean F0",        val: "182",  tr: "+0.6%", dir: "up",   st: "good" },
  { name: "Pitch\nrange",          val: "64",   tr: "-2.3%", dir: "down", st: "warn" },
  { name: "Jitter",                val: "0.012",tr: "-0.4%", dir: "up",   st: "good" },
  { name: "Shimmer",               val: "0.08", tr: "+0.2%", dir: "flat", st: "good" },
  { name: "HNR",                   val: "18.4", tr: "+1.8%", dir: "up",   st: "good" },
  { name: "Syntactic\ncomplexity", val: "0.70", tr: "+0.9%", dir: "up",   st: "good" },
  { name: "Articulation\nrate",    val: "4.8",  tr: "-0.5%", dir: "flat", st: "good" },
  { name: "Emotional\nentropy",    val: "0.65", tr: "-1.2%", dir: "up",   st: "good" },
];

const HEATMAP = [
  "empty","empty","green","green","yellow","green","green",
  "green","green","green","empty","green","green","green",
  "green","yellow","green","green","green","green","red",
  "green","green","green","green","green","yellow","green",
];

const COL = { good: "#2A9060", warn: "#D89010", crit: "#D03050" };

const LogoIcon = () => (
  <svg width="16" height="16" viewBox="0 0 18 18" fill="none">
    <circle cx="9" cy="9" r="5" stroke="#fff" strokeWidth="1.6"/>
    <circle cx="9" cy="9" r="1.8" fill="#fff"/>
    <line x1="9" y1="2"  x2="9"  y2="4"  stroke="#fff" strokeWidth="1.4" strokeLinecap="round"/>
    <line x1="9" y1="14" x2="9"  y2="16" stroke="#fff" strokeWidth="1.4" strokeLinecap="round"/>
    <line x1="2" y1="9"  x2="4"  y2="9"  stroke="#fff" strokeWidth="1.4" strokeLinecap="round"/>
    <line x1="14" y1="9" x2="16" y2="9"  stroke="#fff" strokeWidth="1.4" strokeLinecap="round"/>
  </svg>
);

const Sparkline = ({ status }) => {
  const ref = useRef(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const W = canvas.offsetWidth || 100, H = 26;
    canvas.width = W; canvas.height = H;
    let pts = [], v = 0.5 + Math.random() * 0.2;
    for (let i = 0; i < 14; i++) {
      v += (Math.random() - 0.48) * 0.07;
      v = Math.max(0.1, Math.min(0.9, v));
      pts.push(v);
    }
    const mn = Math.min(...pts), mx = Math.max(...pts), rng = mx - mn || 0.01;
    ctx.beginPath();
    pts.forEach((p, i) => {
      const x = (i / (pts.length - 1)) * W;
      const y = H - ((p - mn) / rng) * (H - 4) - 2;
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.strokeStyle = COL[status] || COL.good;
    ctx.lineWidth = 1.5; ctx.lineJoin = "round"; ctx.lineCap = "round";
    ctx.stroke();
  }, [status]);
  return <canvas ref={ref} className="sparkline" />;
};

const Navbar = ({ active, onNav }) => (
  <nav className="dash-nav">
    <a href="/dashboard" className="nav-logo">
      <div className="nav-logo-box"><LogoIcon /></div>
      <span className="nav-logo-name">CogniSafe</span>
    </a>
    <div className="nav-links">
      {["Dashboard","Session","Brain","Report"].map(p => (
        <button key={p} className={`nav-link ${active === p.toLowerCase() ? "active" : ""}`}
          onClick={() => onNav(p.toLowerCase())}>{p}</button>
      ))}
    </div>
    <div className="nav-right">
      <button className="nav-session-btn" onClick={() => onNav("session")}>+ Start session</button>
      <div className="nav-avatar">AS</div>
    </div>
  </nav>
);

const BiomarkerCard = ({ bm }) => {
  const arrow = bm.dir === "up" ? "▲" : bm.dir === "down" ? "▼" : "—";
  const tClass = bm.dir === "up" ? "up" : bm.dir === "down" ? "down" : "flat";
  return (
    <div className="bm-card">
      <div className="bm-top">
        <span className="bm-name" style={{ whiteSpace: "pre-line" }}>{bm.name}</span>
        <span className={`bm-dot ${bm.st}`} />
      </div>
      <div className="bm-value">{bm.val}</div>
      <div className={`bm-trend ${tClass}`}>{arrow} {bm.tr}</div>
      <Sparkline status={bm.st} />
    </div>
  );
};

const Dashboard = () => {
  const [active, setActive] = useState("dashboard");

  const onNav = (page) => {
    setActive(page);
    window.location.href = `/${page}`;
  };

  return (
    <div className="dash-root">
      <Navbar active={active} onNav={onNav} />
      <div className="dash-body">

        <div className="greeting">
          <div className="greeting-sub">Good morning · Thursday, 20 March</div>
          <div className="greeting-title">Welcome back, <em>Arjun</em> — here's your cognitive pulse</div>
        </div>

        <div className="dash-hero">
          <div className="d-card">
            <div className="card-label">Current risk tier</div>
            <div className="risk-pill"><span className="risk-dot" /> Cognitive health: Good</div>
            <p className="risk-desc">Your voice patterns are stable. No significant changes detected over the last 30 days.</p>
            <p className="risk-updated">Updated today at 9:41 AM</p>
          </div>
          <div className="d-card">
            <div className="card-label">Cognitive age</div>
            <div className="cog-num">52</div>
            <div className="cog-sub">Biological age: 58 — <b>6 yrs younger ✦</b></div>
            <div className="cog-bar-track"><div className="cog-bar-fill" style={{ width: "72%" }} /></div>
          </div>
          <div className="d-card">
            {[
              { label: "Sessions this month", value: "24",   sub: "3 this week"        },
              { label: "Current streak",      value: "12d",  sub: "Personal best: 18d" },
              { label: "Last session",        value: "9h ago", sub: "this morning"     },
            ].map((s, i) => (
              <div className="stat-row" key={i}>
                <div className="stat-row-label">{s.label}</div>
                <div className="stat-row-value">{s.value}</div>
                <div className="stat-row-sub">{s.sub}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="section-header">
          <span className="section-title">Biomarker dashboard</span>
          <span className="section-sub">14 metrics · updated after each session</span>
        </div>
        <div className="chips-row">
          <span className="chip good">11 stable</span>
          <span className="chip watch">3 watch</span>
          <span className="chip note">0 critical</span>
        </div>
        <div className="biomarker-grid">
          {BIOMARKERS.map((bm) => <BiomarkerCard key={bm.name} bm={bm} />)}
        </div>

        <div className="dash-bottom">
          <div className="d-card">
            <div className="report-accent" />
            <div className="report-week">This week, your voice told us…</div>
            <p className="report-narrative">
              Your <b>semantic coherence</b> has been consistently strong this week.
              A slight uptick in pause frequency on Wednesday — possibly fatigue.{" "}
              <b>Overall, your cognitive pulse is stable</b> and trending positively.
            </p>
            <div className="report-actions">
              <button className="report-btn-primary">View full report</button>
              <button className="report-btn-secondary">Share with doctor</button>
            </div>
          </div>
          <div className="d-card">
            <div className="blush-strip">
              <div className="blush-icon">✨</div>
              <div className="blush-text">
                <b>Tip of the day:</b> Morning sessions show 18% higher semantic coherence.
                Try recording before 10 AM for your best results.
              </div>
            </div>
            <div className="section-header">
              <span className="section-title">Session history</span>
              <span className="section-sub">Last 28 days</span>
            </div>
            <div className="heatmap-grid">
              {HEATMAP.map((s, i) => <div key={i} className={`hm-day ${s}`} />)}
            </div>
            <div className="hm-labels">
              {["M","T","W","T","F","S","S"].map((d,i) => <div key={i} className="hm-label">{d}</div>)}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default Dashboard;