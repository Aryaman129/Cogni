import { useState, useRef, useEffect } from "react";
import "../styles/auth.css";

// ── THEME HOOK ─────────────────────────────────────────
const useTheme = () => {
  const [dark, setDark] = useState(true);
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
  }, [dark]);
  return [dark, () => setDark((p) => !p)];
};

// ── ANIMATED GRID BACKGROUND ───────────────────────────
const GridCanvas = () => {
  const ref = useRef(null);
  useEffect(() => {
    const canvas = ref.current;
    const ctx    = canvas.getContext("2d");
    let raf;
    let t = 0;

    const resize = () => {
      canvas.width  = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };

    const draw = () => {
      const W = canvas.width;
      const H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      const isDark = document.documentElement.getAttribute("data-theme") === "dark";
      const lineColor = isDark ? "rgba(30,77,140,0.25)" : "rgba(30,77,140,0.10)";
      const glowColor = isDark ? "rgba(232,160,32,0.06)" : "rgba(232,160,32,0.04)";

      const CELL = 44;
      ctx.strokeStyle = lineColor;
      ctx.lineWidth   = 0.5;

      for (let x = 0; x < W; x += CELL) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, H);
        ctx.stroke();
      }
      for (let y = 0; y < H; y += CELL) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(W, y);
        ctx.stroke();
      }

      // subtle pulse glow in centre
      t += 0.008;
      const glow = 0.5 + 0.5 * Math.sin(t);
      const grad = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, W * 0.55);
      grad.addColorStop(0, glowColor.replace("0.06", String((0.04 + glow * 0.05).toFixed(3))));
      grad.addColorStop(1, "transparent");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, W, H);

      raf = requestAnimationFrame(draw);
    };

    resize();
    draw();
    window.addEventListener("resize", resize);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, []);

  return <canvas ref={ref} className="grid-canvas" />;
};

// ── ICONS ──────────────────────────────────────────────
const LogoIcon = () => (
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
    <circle cx="10" cy="10" r="6" stroke="currentColor" strokeWidth="1.8" />
    <circle cx="10" cy="10" r="2" fill="currentColor" />
    <line x1="10" y1="2"  x2="10" y2="5"  stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    <line x1="10" y1="15" x2="10" y2="18" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    <line x1="2"  y1="10" x2="5"  y2="10" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    <line x1="15" y1="10" x2="18" y2="10" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
  </svg>
);

const SunIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <circle cx="12" cy="12" r="5"/>
    <line x1="12" y1="1"  x2="12" y2="3"/>
    <line x1="12" y1="21" x2="12" y2="23"/>
    <line x1="4.22" y1="4.22"   x2="5.64"  y2="5.64"/>
    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
    <line x1="1"  y1="12" x2="3"  y2="12"/>
    <line x1="21" y1="12" x2="23" y2="12"/>
    <line x1="4.22"  y1="19.78" x2="5.64"  y2="18.36"/>
    <line x1="18.36" y1="5.64"  x2="19.78" y2="4.22"/>
  </svg>
);

const MoonIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/>
  </svg>
);

const GoogleIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24">
    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
  </svg>
);

const GithubIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.166 6.839 9.489.5.092.682-.217.682-.482 0-.237-.008-.866-.013-1.7-2.782.603-3.369-1.342-3.369-1.342-.454-1.155-1.11-1.462-1.11-1.462-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.578 9.578 0 0112 6.836a9.59 9.59 0 012.504.337c1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.202 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.578.688.48C19.138 20.163 22 16.418 22 12c0-5.523-4.477-10-10-10z"/>
  </svg>
);

const LinkedInIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
    <rect width="24" height="24" rx="5" fill="#0A66C2"/>
    <path d="M6.5 10h2v7.5h-2V10zm1-3a1.25 1.25 0 110 2.5A1.25 1.25 0 017.5 7zm4.5 3h1.9v1h.02C14.28 10.4 15.14 10 16.1 10c2.1 0 2.9 1.38 2.9 3.17V17.5h-2v-4c0-.76-.01-1.73-1.06-1.73-1.06 0-1.22.83-1.22 1.68V17.5H12V10z" fill="#fff"/>
  </svg>
);

// ── STRENGTH BAR ───────────────────────────────────────
const getScore = (p) => {
  let s = 0;
  if (p.length >= 8)          s++;
  if (/[A-Z]/.test(p))        s++;
  if (/[0-9]/.test(p))        s++;
  if (/[^A-Za-z0-9]/.test(p)) s++;
  return s;
};
const S_COLORS = ["#E24B4A","#EF9F27","#EF9F27","#1D9E75"];
const S_LABELS = ["Weak","Fair","Good","Strong"];

const StrengthBar = ({ password }) => {
  const score = getScore(password);
  return (
    <div className="strength-wrap">
      <div className="strength-bar">
        {[0,1,2,3].map((i) => (
          <div key={i} className="strength-seg"
            style={{ background: i < score ? S_COLORS[score-1] : undefined }} />
        ))}
      </div>
      {score > 0 && (
        <span className="strength-label" style={{ color: S_COLORS[score-1] }}>
          {S_LABELS[score-1]}
        </span>
      )}
    </div>
  );
};

// ── LEFT PANEL ─────────────────────────────────────────
const LeftPanel = () => (
  <div className="auth-left">
    <GridCanvas />
    <div className="left-inner">

      <div className="brand">
        <div className="brand-icon"><LogoIcon /></div>
        <span className="brand-name">CogniSafe</span>
      </div>

      <div className="left-hero">
        <div className="left-badge">Early Detection Platform</div>
        <h1 className="left-title">
          Hear the<br />
          <span className="left-title-accent">sound</span> of<br />
          your mind.
        </h1>
        <p className="left-desc">
          Voice biomarkers detect cognitive changes up to
          18 months before symptoms appear — passively,
          daily, privately.
        </p>

        <div className="feature-list">
          {[
            { icon: "◎", label: "14 biomarkers per session" },
            { icon: "◈", label: "3 minute daily sessions" },
            { icon: "◇", label: "HIPAA compliant & encrypted" },
          ].map((f) => (
            <div className="feature-item" key={f.label}>
              <span className="feature-icon">{f.icon}</span>
              <span className="feature-text">{f.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="left-stats">
        {[
          { num: "18mo", label: "early detection" },
          { num: "150M", label: "at risk by 2050" },
          { num: "99%",  label: "data encrypted"  },
        ].map((s) => (
          <div className="stat-item" key={s.label}>
            <span className="stat-num">{s.num}</span>
            <span className="stat-label">{s.label}</span>
          </div>
        ))}
      </div>

    </div>
  </div>
);

// ── RIGHT PANEL ────────────────────────────────────────
const RightPanel = ({ mode, onSwitch, dark, toggleTheme }) => {
  const isReg = mode === "register";

  const [form, setForm]     = useState({ firstName:"", lastName:"", email:"", password:"", dob:"" });
  const [errors, setErrors] = useState({ email:"", password:"" });
  const [loading, setLoad]  = useState(false);
  const [showPass, setShow] = useState(false);

  const update = (f) => (e) => setForm((p) => ({ ...p, [f]: e.target.value }));

  const validate = () => {
    const e = { email:"", password:"" };
    let ok = true;
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      e.email = "Enter a valid email address"; ok = false;
    }
    if (isReg && form.password && form.password.length < 8) {
      e.password = "Minimum 8 characters required"; ok = false;
    }
    setErrors(e);
    return ok;
  };

  const switchMode = (m) => {
    setErrors({ email:"", password:"" });
    setForm({ firstName:"", lastName:"", email:"", password:"", dob:"" });
    onSwitch(m);
  };

  const submit = () => {
    if (!validate()) return;
    setLoad(true);
    setTimeout(() => {
  setLoading(false);
  window.location.href = "/dashboard";
}, 1400);
  };

  return (
    <div className="auth-right">

      {/* Theme toggle */}
      <button className="theme-btn" onClick={toggleTheme} title="Toggle theme">
        {dark ? <SunIcon /> : <MoonIcon />}
      </button>

      <div className="form-wrap">

        <div className="form-head">
          <h2 className="form-title">{isReg ? "Create account" : "Welcome back"}</h2>
          <p className="form-sub">
            {isReg ? "Start your cognitive health journey" : "Sign in to your dashboard"}
          </p>
        </div>

        {/* Toggle */}
        <div className="mode-toggle">
          <button className={`mode-btn ${!isReg ? "on" : ""}`} onClick={() => switchMode("login")}>Sign in</button>
          <button className={`mode-btn ${isReg ? "on" : ""}`}  onClick={() => switchMode("register")}>Register</button>
        </div>

        {/* Name row — register only */}
        {isReg && (
          <div className="field-row slide-in">
            <div className="field">
              <label>First name</label>
              <input type="text" placeholder="Arjun" value={form.firstName} onChange={update("firstName")} />
            </div>
            <div className="field">
              <label>Last name</label>
              <input type="text" placeholder="Sharma" value={form.lastName} onChange={update("lastName")} />
            </div>
          </div>
        )}

        {/* Email */}
        <div className="field">
          <label>Email address</label>
          <input type="email" placeholder="you@example.com" value={form.email}
            onChange={(e) => { update("email")(e); validate(); }} />
          {errors.email && <span className="field-err">{errors.email}</span>}
        </div>

        {/* Password */}
        <div className="field">
          <label>Password</label>
          <div className="pass-wrap">
            <input type={showPass ? "text" : "password"} placeholder="••••••••"
              value={form.password}
              onChange={(e) => { update("password")(e); validate(); }}
              autoComplete={isReg ? "new-password" : "current-password"} />
            <button className="eye-btn" onClick={() => setShow((p) => !p)} type="button">
              {showPass ? "Hide" : "Show"}
            </button>
          </div>
          {isReg && form.password && <StrengthBar password={form.password} />}
          {errors.password && <span className="field-err">{errors.password}</span>}
        </div>

        {/* DOB — register only */}
        {isReg && (
          <div className="field slide-in">
            <label>Date of birth</label>
            <input type="date" value={form.dob} onChange={update("dob")} />
          </div>
        )}

        {/* Forgot */}
        {!isReg && (
          <div className="forgot">
            <a href="#">Forgot password?</a>
          </div>
        )}

        {/* Submit */}
        <button className="submit-btn" onClick={submit} disabled={loading}>
          <span className="btn-shine" />
          <span className="btn-text">
            {loading ? "Please wait…" : isReg ? "Create account" : "Sign in"}
          </span>
        </button>

        {/* Divider */}
        <div className="divider">
          <span className="div-line" />
          <span className="div-text">or continue with</span>
          <span className="div-line" />
        </div>

        {/* Socials */}
        <div className="socials">
          <button className="soc-btn"><GoogleIcon /><span>Google</span></button>
          <button className="soc-btn"><GithubIcon /><span>GitHub</span></button>
          <button className="soc-btn"><LinkedInIcon /><span>LinkedIn</span></button>
        </div>

        {/* Switch */}
        <p className="switch">
          {isReg
            ? <>Already have an account? <a href="#" onClick={(e) => { e.preventDefault(); switchMode("login"); }}>Sign in</a></>
            : <>No account yet? <a href="#" onClick={(e) => { e.preventDefault(); switchMode("register"); }}>Create one free</a></>
          }
        </p>

      </div>
    </div>
  );
};

// ── PAGE ───────────────────────────────────────────────
const Auth = () => {
  const [mode, setMode]       = useState("login");
  const [dark, toggleTheme]   = useTheme();

  return (
    <div className="auth-page">
      <div className="auth-card">
        <LeftPanel />
        <RightPanel mode={mode} onSwitch={setMode} dark={dark} toggleTheme={toggleTheme} />
      </div>
    </div>
  );
};

export default Auth;